#ifndef _APP_SYS_H
#define _APP_SYS_H

#include "SysApp/AppPage.h"
#include "SysApp/AppParam.h"


void app_BspInit( SysParam_t *p_SysParamHandle );
void app_Process( SysParam_t *p_SysParamHandle );

#endif /* _APP_SYS_H */

